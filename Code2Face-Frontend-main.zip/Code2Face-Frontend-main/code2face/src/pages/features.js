import React from 'react'

const Features = () => {
  return (
    <div className='cen-container  mt-5 l-shadow mot'>
        <h2>Features</h2>
        <ul>
            <li>Video Chatting</li>
            <li>Screen Sharing</li>
            <li>Face Monitoring</li>
            <li>Collaborative Code Editor</li>
            <li>Online Compiler</li>
        </ul>
    </div>
  )
}

export default Features