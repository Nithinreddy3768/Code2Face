import React from 'react'

const NotFound = () => {
  return (
    <div className='errorpage'><span>Sorry, the request resources are not available on this website</span></div>
  )
}

export default NotFound